<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:films="http://38thsense"
    xmlns:xs="http://www.w3.org/2001/XMLSchema" exclude-result-prefixes="xs" version="2.0">
    
    <xsl:output method="xml" indent="true"/>

    <xsl:function name="films:randorg">
        <xsl:param name="max"/>
            
           <xsl:value-of select="replace(unparsed-text(concat('https://www.random.org/integers/?num=1&amp;min=1&amp;max=', $max, '&amp;col=1&amp;base=10&amp;format=plain&amp;rnd=new')),'&#xA;', '')"/>
        
    </xsl:function>

    <xsl:template match="node() | @*">
        <xsl:apply-templates/>
    </xsl:template>

    <xsl:template match="cinetek">

        <xsl:variable name="dir-num" select="count(director)"/>

        <xsl:variable name="seq-num">
            <xsl:value-of select="films:randorg($dir-num)"/>
        </xsl:variable>

        <xsl:variable name="chosen" select="./director[position() = xs:integer($seq-num)]"/>

        <xsl:variable name="cinesource"
            select="doc(concat(replace(base-uri(/), '[^/]+$', ''),'la-cinetek.xml'))/la-cinetek/la-liste-de[@name = $chosen/text()]"/>

<!--                <xsl:variable name="cinesource" select="doc('la-cinetek.xml')/la-cinetek/la-liste-de[@name='Alain Chabat']"/>-->

        <chosen num="{$seq-num}">
            <xsl:copy-of select="$chosen"/>


            <xsl:choose>
                <xsl:when test="count($cinesource/film) != 0">
                    <xsl:variable name="list-size"
                        select="$cinesource/@list-size"/>

                    <listicle> Found director in DB with <xsl:value-of select="$list-size"/>
                        masterpieces! </listicle>
                    
                   <xsl:variable name="chnum" select="films:randorg($list-size)"/>
                    
                    <randorg><xsl:value-of select="$chnum"/></randorg>
                    
                    <xsl:variable name="chfilm" select="$cinesource/film[position()=$chnum]"/>
                    
                    
                    <film>
                        <title><xsl:value-of select="$chfilm/title"/></title>
                        <director><xsl:value-of select="$chfilm/director"/></director>
                        <year><xsl:value-of select="$chfilm/year"/></year><country><xsl:value-of select="$chfilm/country"/></country>
                        <watched source="cin" recommended-by="{$chosen}"><xsl:value-of select="format-date(current-date(), '[Y0001]-[M01]-[D01]')" /></watched></film>
                    
<!--                    <xsl:copy-of select="$chfilm"/>-->

                </xsl:when>
                
                <xsl:when test="$chosen/@list-size != ''">
                    
                    <xsl:variable name="list-seq" select="films:randorg($chosen/@list-size)"/>
                    
                    <listicle> Watch film number <xsl:value-of select="$list-seq"/>.</listicle>
                    
                </xsl:when>
                
                <xsl:otherwise>
                    <listicle>Go to Cinetek.</listicle>
                </xsl:otherwise>
                
            </xsl:choose>

        </chosen>

    </xsl:template>

    <!-- -->


</xsl:stylesheet>
