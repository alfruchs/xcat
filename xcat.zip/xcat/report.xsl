<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    exclude-result-prefixes="xs oxy"
    xmlns:oxy="http://www.oxygenxml.com/ns/author/xpath-extension-functions" 
    version="2.0">
    
    <xsl:output method="xml" encoding="UTF-8"/>
    
    <xsl:variable name="zero-bank" select="'                                                                                                                                                                                                                                                                    '"/>
    <xsl:variable name="cell-length" select="50"/>
    <xsl:variable name="rule" select="concat('+',substring(translate($zero-bank,' ','-'),1,$cell-length+2))"/>
    
    <xsl:template match="node()|@*">
        <xsl:apply-templates/>
    </xsl:template>
    
    <xsl:template match="/">
        <rep-text>
            <xsl:apply-templates/>
        </rep-text>
    </xsl:template>
    
    <xsl:template match="music//*[@report = 'true']">
        <xsl:variable name="entity" select="./local-name()"/>
        <xsl:variable name="winner" select="normalize-space(./text())"/>
<!--        <xsl:message><xsl:value-of select="concat($entity,'||',$winner)"/></xsl:message>-->
        <xsl:for-each select="//*[local-name()=$entity and normalize-space(lower-case(./text())) = lower-case($winner)]">
            <xsl:sort select="ancestor-or-self::carrier/title[last()]/@release-date" />
            <xsl:variable name="artist" select="normalize-space(string-join(ancestor-or-self::carrier/artist[not(exists(@part))],', '))"/>
            <xsl:variable name="title" select="normalize-space(string-join(ancestor-or-self::carrier/title,', '))"/>
            <xsl:variable name="year" select="string-join(ancestor-or-self::carrier/title/@release-date,'; ')"/>
            <rep-line><xsl:value-of select="$rule"/><xsl:value-of select="$rule"/>+-----------+</rep-line>
            <rep-line>| <xsl:value-of select="substring(concat($artist, $zero-bank),1, $cell-length)"/> | <xsl:value-of select="substring(concat($title, $zero-bank),1, $cell-length)"/> | <xsl:value-of select="substring(concat($year, $zero-bank),1, 9)"/> |</rep-line>
        </xsl:for-each>
            <rep-line><xsl:value-of select="$rule"/><xsl:value-of select="$rule"/>+-----------+</rep-line>    
    </xsl:template>
    
    <xsl:template match="films//*[@report = 'true']">
        <xsl:variable name="entity" select="./local-name()"/>
        <xsl:variable name="winner" select="normalize-space(./text())"/>
        <rep-text>
<!--            <xsl:message><xsl:value-of select="concat($entity,'||',$winner)"/></xsl:message>-->
            <xsl:for-each select="//*[local-name()=$entity and normalize-space(lower-case(./text())) = lower-case($winner)]">
                <xsl:sort select="ancestor-or-self::film/year" />
                <xsl:variable name="artist" select="normalize-space(string-join(ancestor-or-self::film/director,', '))"/>
                <xsl:variable name="title" select="normalize-space(string-join(ancestor-or-self::film/title,', '))"/>
                <xsl:variable name="year" select="ancestor-or-self::film/year"/>
                <rep-line><xsl:value-of select="$rule"/><xsl:value-of select="$rule"/>+-----------+-----+</rep-line>
                <rep-line>| <xsl:value-of select="substring(concat($artist, $zero-bank),1, $cell-length)"/> | <xsl:value-of select="substring(concat($title, $zero-bank),1, $cell-length)"/> | <xsl:value-of select="substring(concat($year, $zero-bank),1, 9)"/> | <xsl:value-of select="substring(concat(ancestor-or-self::film/../@label,ancestor-or-self::cinetek/@label,' '),1,3)"/> |</rep-line>
            </xsl:for-each>
            <rep-line><xsl:value-of select="$rule"/><xsl:value-of select="$rule"/>+-----------+-----+</rep-line>
        </rep-text>
    </xsl:template>
    
</xsl:stylesheet>